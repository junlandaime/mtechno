<div id="fh5co-page">
	<header id="fh5co-header" role="banner">
		<div class="container">
			<div class="header-inner">
				<h1><a href="<?php echo base_url().''?>">Nuclear<span></span></a></h1>
				<nav role="navigation">
					<ul>
						<li><a href="<?php echo base_url().''?>">Home</a></li>
						<li><a href="<?php echo base_url().'lecturer'?>">Lecturer</a></li>
						<li><a href="<?php echo base_url().'roadmap'?>">Roadmap</a></li>
						<li><a href="<?php echo base_url().'artikel'?>">Information</a></li>
						<li><a href="<?php echo base_url().'gallery'?>">Gallery</a></li>
						<li><a href="<?php echo base_url().'kontak'?>">Contact</a></li>
						<li class="cta"><a href="<?php echo base_url().'roadmap'?>">Get started</a></li>
					</ul>
				</nav>
			</div>
		</div>
	</header> 